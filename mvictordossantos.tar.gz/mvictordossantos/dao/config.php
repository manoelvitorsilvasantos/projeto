<?php 
    class Config
    {
        protected $host = "localhost:3306";
        protected $user = "root";
        protected $pass = "root";
        protected $dbname = "base_cliente";
    }
?>