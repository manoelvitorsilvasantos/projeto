<?php

    class Conexao
    {

        public function __construct(){}
        public function __destruct()
        {
            $this->desconectar();
        }

        private static $dbtype = "mysql";
        private static $host = "localhost";
        private static $port = "3306";
        private static $user = "root";
        private static $pass = "root";
        private static $dbname = "base_cliente";

        private function getDbType() { return self::$dbtype;}
        private function getHost() { return self::$host;}
        private function getPOrt() { return self::$port;}
        private function getUser() { return self::$user;}
        private function getPass() { return self::$pass;}
        private function getDbname() { return self::$dbname;}

        private function conectar()
        {
            try
            {
                $this->conexao = new PDO($this->getDbType().":host=".$this->getHost().";port=".$this->getPort().";dbname=".$this->getdbname(), $this->getUser(), $this->getPass());
            }
            catch(PDOException $ex)
            {
                die( "Erro <code>".$ex->getMessage()."</code>");
            }
        }

        private function desconectar()
        {
            $this->conexao = null;
        }

		
    }

?>
