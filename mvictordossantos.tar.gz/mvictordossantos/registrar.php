<?php 

    include_once 'conexao.php';

    $conn = new Conexao();


    //dados pessoais
	$matricula = $_POST['matricula'];
    $nome = $_POST['nome']." ".$_POST['sobrenome'];
    $cpf = $_POST['cpf'];
    $rg = $_POST['rg'];
    $dn = $_POST['dn'];
	$sexo = $_POST['sexo'];

	//dados contato
	$cel = $_POST['cel'];
	$email = $_POST['email'];

	
	//dados endereco
	$rua = $_POST['rua'];
	$bairro = $_POST['bairro'];
	$numero = $_POST['numero'];
	$complemento = $_POST['complemento'];
	$cidade = $_POST['cidade'];
	$estado = $_POST['estado'];
	$cep = $_POST['cep'];
	
	$tbl_dados_sql = "INSERT INTO tbl_dados_cl(matricula,nome, cpf, rg, dn, sexo) VALUES($matricula, '$nome', '$cpf', '$rg', '$dn', '$sexo')";	
	$tbl_contato_sql = "INSERT INTO tbl_contatos_cl(matricula, cel, email, tbl_dados_cl_matricula) VALUES($matricula,'$cel', '$email', $matricula)";
	$tbl_endereco_sql = "INSERT INTO tbl_endereco_cl(matricula, rua, bairro, numero, cep, complemento, tbl_dados_cl_matricula) VALUES ($matricula,'$rua', '$bairro', $numero, '$cep', '$complemento', $matricula)";
	
	if($conn->isExists($matricula))
	{
		$conn->executarQuery($tbl_dados_sql);
		$conn->executarQuery($tbl_contato_sql);
		$conn->executarQuery($tbl_endereco_sql);
		header('Location: sucesso.php');
	}
	else
	{
		header('Location: fails.php');
	}
	$conn->fechar();
?>
