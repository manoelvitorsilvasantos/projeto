<!doctype>
<html lang="pt-br">
    <?php include("head.php"); ?>
    <body>
        <div class="conteudo_center">
            </br>
            </br>
            </br>
            <form action="login.php" method="POST">
                <fieldset>
                    <legend>Tela de Login</legend>
                    </br>
                    </br>
                    <label>Usu&aacute;rio</label>
                    <input name="login" type="text"></br></br>
                    <label>Senha</label>
                    <input name="senha" type="password"></br></br> </br> </br>

                    <input value="Logar" type="submit">
                    </br></br>
                </fieldset>
            </form>
            </br>
            </br>
            </br>
        </div>
        <div class="menu">
            <b>
            <p> Desenvolvido por Manoel Vitor </p>
            <p>Todos Direitos Reservados para Manoel Vitor</p>
            </b>
        </div>
    </body>
</html>
