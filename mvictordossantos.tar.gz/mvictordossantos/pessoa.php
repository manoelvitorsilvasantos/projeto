<?php
    class Pessoa
    {
        
    }
?>