<html>
	<head>
		<title> md5 criptografia </title>
	</head>
	<body>
		<form action="" method="post">
		<label> Digite a senha </label>
		<input type="text" name="senha">
		</br></br>
		<input type="submit" value="Encriptar" name="encriptar">
		</form> 

		<?php
			$senha = $_POST['senha'];
			$resultado = md5($senha);
			printf("<font color='red'> <p>Senha ecriptada &eacute; = %s </p></font> %s", md5($senha), $senha);
		?>
	</body>
</html>
