<?php

	
	include_once 'conexao.php';
	session_start();
	
	$conn = new Conexao();

	$user = $_POST["login"];
	$pass = $_POST["senha"];

	$senha = md5($pass);

	$link  = $conn->executarQuery("SELECT login, senha FROM tbl_usuarios WHERE login = '$user' AND senha = '$senha'");
	
	$contador = mysqli_num_rows($link);


	if($contador >= 1)
	{
		//deixa a sessão conectado ate 5 minutos
		session_cache_expire(10);
		$_SESSION['login'] = $user;
		$_SESSION['senha'] = $senha;
		header('Location: home.php');
	}
	else
	{
		unset($_SESSION['login']);
		unset($_SESSION['senha']);
		header('Location: error.php');
	}

?>
