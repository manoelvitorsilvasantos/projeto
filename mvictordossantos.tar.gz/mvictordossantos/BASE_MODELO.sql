-- -----------------------------------------------------
-- Table `mydb`.`tbl_dados_cl`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS tbl_dados_cl (
  matricula INT NOT NULL,
  nome VARCHAR(50) NOT NULL,
  cpf VARCHAR(15) NOT NULL,
  rg VARCHAR(13) NOT NULL,
  dn VARCHAR(10) NOT NULL,
  sexo ENUM('MASCULINO', 'FEMININO') NOT NULL,
  PRIMARY KEY (`matricula`));


-- -----------------------------------------------------
-- Table `mydb`.`tbl_contatos_cl`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS tbl_contatos_cl(
  matricula INT NOT NULL,
  cel VARCHAR(15) NOT NULL,
  email VARCHAR(45) NOT NULL,
  tbl_dados_cl_matricula INT NOT NULL,
  FOREIGN KEY(tbl_dados_cl_matricula) REFERENCES tbl_dados_cl(matricula),
  PRIMARY KEY (`matricula`));


-- -----------------------------------------------------
-- Table `mydb`.`tbl_endereco_cl`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS tbl_endereco_cl (
  matricula INT NOT NULL,
  rua VARCHAR(60) NOT NULL,
  bairro VARCHAR(45) NOT NULL,
  numero INT NOT NULL,
  cep VARCHAR(11) NOT NULL,
  complemento VARCHAR(25) NOT NULL,
  tbl_dados_cl_matricula INT NOT NULL,
  FOREIGN KEY(tbl_dados_cl_matricula) REFERENCES tbl_dados_cl(matricula),
  PRIMARY KEY (`matricula`));