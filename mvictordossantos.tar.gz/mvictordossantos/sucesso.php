<!doctype>
<html lang="pt-br">
    <?php include("head.php"); ?>
    <body>
        <div class="conteudo_center">
            </br>
            </br>
            </br>
            <h2> Cadastrado com sucesso... </h2>
            </br>
            </br>
            </br>
        </div>
        <div class="menu">
            <b>
            <p> Desenvolvido por Manoel Vitor </p>
            <p>Todos Direitos Reservados para Manoel Vitor</p>
            </b>
        </div>
    </body>
</html>
