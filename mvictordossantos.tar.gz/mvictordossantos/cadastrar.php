<!doctype>
<html lang="pt-br">
    <?php 
        include_once './utils/verificar_session.php';
        include_once 'head.php'; 
    ?>
    <body>
        <?php include_once 'menu.php'; ?>
        <div align="center" class="conteudo_center">
        </br>
        </br>        
        <form  name="form" action="registrar.php" method="POST" >
                </br>
                <h3 align="right"> Formulário de Cadastro</h3>
                </br>
                </br>
                <fieldset>
                    <legend>Dados Pessoais</legend>
                    <label>Nome: </label>
                    <input type="text" maxlength="60" placeholder="nome" name="nome" onblur="ValidarNome(form.nome);" pattern="[a-zA-Zà-úÀ-Ú\s]+$" title="Digite letras mínusculas!"  required></br></br>
                    <label>Sobrenome: </label>
                    <input type="text" maxlength="60" placeholder="sobrenome" name="sobrenome" onblur="ValidarNome(form.sobrenome);" pattern="[a-zA-Zà-úÀ-Ú\s]+$" title="Digite letras mínusculas!"  required></br></br>
                    <label>Número de Matricula: </label>
                    <input type="text" maxlength="8" placeholder="Digite o n&uacute;mero de matricula" onkeypress="MascaraMatricula(form.matricula);" onblur="ValidarMatricula();" name="matricula" pattern="[0-9]+$" required>
                    </br></br>
                    <label>CPF: </label>
                    <input type="text" name="cpf" onkeypress="MascaraCPF(form.cpf);" onblur="ValidarCPF(form.cpf);" maxlength="14" placeholder="Digite o número do CPF" required>
                    <div style="display:none;" id="valido">CPF V&aacute;lido</div>
                    <div style="display:none;" id="invalido">CPF Iv&aacute;lido</div>
                    </br></br>

                    <label>RG: </label>
                    <input type="text" name="rg" onkeypress="MascaraRG(form.rg);"  maxlength="12" placeholder="Digite o número do RG" required></br></br>

                    <label>Data Nasc.: </label>
                    <input type="text" name="dn" onkeypress="MascaraData(form.dn);" onblur="validaData(form.dn);" placeholder="00/00/0000" maxlength="10" required></br></br>
					<label> Sexo: </label>  </br> </br>
                    <select name="sexo" onblur="verificar();" required>
                        <option value="none">Selecione uma op&ccedil;&atilde;o</option>
                        <option value="MASCULINO">Masculino</option>
                        <option value="FEMININO">Feminino</option>	
                    </select> </br></br>

                    <label>E-mail: </label>
                    <input type="email" maxlenght="50" placeholder="seuemail@dominio.com" name="email" onblur="ValidarEmail(form.email);" placeholder="seuemail@dominio.com" autocomplete="on" required></br></br>

                    <label>Confirmar E-mail: </label>
                    <input type="email" placeholder="Repetir seuemail@dominio.com" name="email_confirma" onblur="ValidarEmail(form.email_confirma);" required></br></br>

                    <label>Celular: </label>
                    <input type="text" name="cel" onkeypress="MascaraCelular(form.cel);" onblur="validaCelular(form.cel);" placeholder="(00) 00000-0000" maxlength="15" required></br></br>
                </fieldset>
                </br></br>
                <fieldset>
                    <legend > Endereço</legend>
                    <label> Rua: </label> 
                    <input type="text" placeholder="Digite o seu endereco de rua" autocomplete="on" name="rua" required></br></br> 

                    <label> Bairro: </label> 
                    <input type="text" placeholder="Digite o nome do Bairro" autocomplete="on" name="bairro" required></br></br>
                            
                    <label> Cidade: </label> 
                    <input type="text" placeholder="Digite o nome da cidade" autocomplete="on" name="cidade" required></br></br>
                            
                    <label> Estado: </label> 
                    <select name="estado" onblur="verificar();" required>
                        <option value="none">Selecione uma op&ccedil;&atilde;o</option>
                        <option value="Acre">Acre</option>
                        <option value="Alagoas">Alagoas</option>
                        <option value="Amap&aacute;">Amap&aacute;</option>
                        <option value="Amazonas">Amazonas</option>
                        <option value="Bahia">Bahia</option>
                        <option value="Cear&aacute;">Cear&aacute;</option>
                        <option value="Distrito Federal">Distrito Federal</option>
			<option value="Esp&iacute;rito Santo">Esp&iacute;rito Santo</option>
			<option value="Goi&aacute;s">Goi&aacute;s</option>
			<option value="Maranh&atilde;o">Maranh&atilde;o</option>
			<option value="Mato Grosso">Mato Grosso</option>
			<option value="Mato Grosso do Sul">Mato Grosso do Sul</option>
			<option value="Minas Gerais">Minas Gerais</option>
			<option value="Par&aacute;">Par&aacute;</option>
			<option value="Para&aicute;ba">Para&aicute;ba</option>
			<option value="Piau&iacute;">Piau&iacute;</option>
			<option value="Rio de Janeiro">Rio de Janeiro</option>
			<option value="Rio Grande do Sul">Rio Grande do Sul</option>
			<option value="Rio Grande do Norte">Rio Grande do Norte</option>
                        <option value="Rond&ocirc;nia">Rond&ocirc;nia</option>
                        <option value="Roraima">Roraima</option>
                        <option value="Santa Catarina">Santa Catarina</option>
                        <option value="S&atilde;o Paulo">S&atilde;o Paulo</option>
                        <option value="Sergipe">Sergipe</option>
                        <option value="Tocantins">Tocantins</option>

                    </select>
                    </br>
                    </br>
                    <label> CEP:</label>
                    <input type="text" autocomplete="on" name="cep" onkeypress="MascaraCep(form.cep);" onblur="validaCep(form.cep);" maxlength="10" placeholder="00.000-000" required> </br></br>

                    <label> Complemento: </label> 
                    <input type="text" autocomplete="on" name="complemento" required></br></br>

                    <label> Número: </label> 
                    <input type="number" placeholder="Digite o número" autocomplete="off" pattern="[0-9]+$" name="numero" required>
                    </br>
                    </br>
                </fieldset>
                </br>
                </br>
                    <input type="submit" value="cadastrar">
                </br>
                </br>
                <input type="reset" value="Limpar">                
            </form>
        </div>
    </body>
</html>
