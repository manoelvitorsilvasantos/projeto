<head>
    <meta charset="UTF-8"/>
    <title> Info SEC </title>
    <meta name="author" content="manoel vitor"/>
    <meta name="about" content="crud basic"/>
    <link rel="stylesheet" href="./css/estilo.css">
    <script type="text/javascript" src="./js/script.js"/></script>
    <script type="text/javascript" src="./js/md5.js"/></script>
    
</head>
