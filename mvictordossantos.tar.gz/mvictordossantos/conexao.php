<?php
	
	class Conexao
	{
		private static $host = "localhost:3306";
		private static $user = "root";
		private static $pass = "root";
		private static $dbname = "base_cliente";

		private function getHost(){ return self::$host;}
		private function getUser(){ return self::$user;}
		private function getPass(){ return self::$pass;}
		private function getDbname(){ return self::$dbname;}
	
		
		private function conectar()
		{
			return mysqli_connect($this->getHost(), $this->getUser(), $this->getPass(), $this->getDbname());
		}

		public function executarQuery($query)
		{
			return mysqli_query($this->conectar(), $query);
		}

		public function isExists($matricula)
		{
			$sql = "select d.matricula, d.cpf, d.rg, c.matricula, c.cel, c.email, e.matricula from tbl_dados_cl as d";
			$sql .="inner join tbl_contatos_cl as c on c.matricula = d.matricula";
			$sql .="inner join tbl_endereco_cl as e on e.matricula = d.matricula where d.matricula = $matricula and c.matricula = $matricula and e.matricula = $matricula";
			$resultado = $this->executarQuery($sql);
			if(!$resultado)
			{
				return false;
			}
			else
			{
				return true;
			}
		}

		public function fechar()
		{
			return mysqli_close($this->conectar());
		}

		

	}

?>
