<div class="lista">
    <h3> Titulo</h3> </br> </br>
    <p> loren </p>
</div>