<html>
    <head>
        <title> Calculadora</title>
    </head>

    <body>
        <form action="" method="POST">
            <label> Valor 1</label>
            <input name="x" type="number" required>
            <label> Valor 1</label>
            <input name="y" type="number" required>
            </br> </br>
            <input name="operacao" type="submit" value="+">
            <input name="operacao" type="submit" value="-">
            <input name="operacao" type="submit" value="*">
            <input name="operacao" type="submit" value="/">
        </form>

        <?php
            $valor1 = $_POST['x'];
            $valor2 = $_POST['y'];
            $operacao = $_POST["operacao"];

            if($operacao == '+')
            {
                if($valor1 == 0 && $valor2 == 0)
                {
                    printf("<b> Campo vázio!</b>");
                }
                else{
                    $resultado = $valor1+$valor2;
                    printf("<b> %d </b>", $resultado );
                }
            }
            else if($operacao == '-')
            {
                if($valor1 == 0 && $valor2 == 0)
                {
                     printf("<b> Campo vázio!</b>");
                }
                else{
                    $resultado = $valor1-$valor2;
                    printf("<b> %d </b>", $resultado );
                }
            }
            else if($operacao == '*')
            {
                if($valor1 == 0 && $valor2 == 0)
                {
                     printf("<b> Campo vázio!</b>");
                }
                else{
                    $resultado = $valor1*$valor2;
                    printf("<b> %d </b>", $resultado );
                }
            }
            else if($operacao == '/')
            {
                if($valor2 == 0)
                {
                    printf("<b> Erro, voc&ecirc; n&atilde;o pode dividir por zero!</b>");
                }
                
                else{
                    $resultado = $valor1/$valor2;
                    printf("<b> %d </b>", $resultado );
                }
            }
            else
            {
                printf("Campos vázios");
            }

        ?>
    </body>

</html>