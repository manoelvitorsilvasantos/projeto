<div class="menu">
    <a href="home.php">Tela Principal</a>
    <a href="cadastrar.php">Cadastrar</a>
    <a href="#">Listar</a>
    <a href="#">Remover</a>
    <a href="#">Atualizar</a>
    <a href="sair.php">Sair</a>
</div>
