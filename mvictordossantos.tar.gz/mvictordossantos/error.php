<!doctype>
<html lang="pt-br">
    <?php include("head.php"); ?>
    <body>
        <div class="conteudo_center">
            </br>
            </br>
            </br>
            <h3> Erro, Usu&aacute;rio ou Senha incorreto!</h3>
            <a href="index.php">Voltar </a>
            </br>
            </br>
            </br>
        </div>
        <div class="menu">
            <b>
            <p> Desenvolvido por Manoel Vitor </p>
            <p>Todos Direitos Reservados para Manoel Vitor</p>
            </b>
        </div>
    </body>
</html>
