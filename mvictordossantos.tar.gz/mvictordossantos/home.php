<!doctype>
<html lang="pt-br">
    <?php 
        include_once './utils/verificar_session.php';
        include_once 'head.php'; 
    ?>
    <body>
        <?php
				include_once 'menu.php';
			?>
        <div class="menu">
            <b>
            <p> Desenvolvido por Manoel Vitor </p>
            <p>Todos Direitos Reservados para Manoel Vitor</p>
            </b>
        </div>
    </body>
</html>
