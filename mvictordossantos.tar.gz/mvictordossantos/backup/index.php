
<!doctype>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="author" content="manoel vitor">
        <title> TELA DE LOGIN</title>
        <link rel="stylesheet" type="text/css" href="estilo.css">
    </head>

    <body>
  
    <?php
        include("form_login.php");
    ?>

    </body>

</html>
