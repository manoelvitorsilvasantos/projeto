<?php

	session_start();
   	
   	$id = $_SESSION["id"];
   	$email = $_SESSION["email"];
   	$senha = $_SESSION["senha"];
   	$nome = $_SESSION["nome"];

   	if(!isset($_SESSION["email"]) && !isset($_SESSION["senha"]) && !isset($_SESSION["id"]) && !isset($_SESSION["nome"]))
   	{	
   		header('Location: index.php');
   		exit;
   	}

?>