<?php

    $link = mysqli_connect("localhost:3306", "root", "root", "base_cliente");
    mysqli_query($link, "CREATE TABLE IF NOT EXISTS tbl_cliente(cod int auto_increment not null primary key, nome varchar(45) not null, cpf varchar(15) not null, rg varchar(13) not null, DN varchar(10) not null)");
    mysqli_query($link, "CREATE TABLE IF NOT EXISTS tbl_cliente_contado(id int auto_increment not null primary key, cel varchar(15) not null, email varchar(60) not null, email_confirma varchar(60) not null)");
    mysqli_query($link, "CREATE TABLE IF NOT EXISTS tbl_endereco (id int auto_increment not null primary key, rua varchar(50) not null, bairro varchar(40) not null, numero int not null, cep varchar(11) not null, complemento varchar(50) not null, estado varchar(30) not null, cidade varchar(30)NOT NULL )");
    mysqli_query($link, "CREATE TABLE IF NOT EXISTS tblUnidas(tbl_cliente INT NOT NULL, tbl_cliente_contato INT NOT NULL, tbl_endereco INT NOT NULL)");

    $nome = "teste";
    $rg = "84848489989";
    $cpf = "323432423";
    $dn = "11/11/6526";

    mysqli_query($link, "INSERT INTO tbl_cliente(nome, cpf, rg, DN) values('$nome','$cpf','$rg','$dn')");

?>