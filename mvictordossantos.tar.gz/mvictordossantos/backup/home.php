
<!doctype>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="author" content="manoel vitor">
        <title> INFO CLIENTE</title>
        <link rel="stylesheet" type="text/css" href="estilo.css">
    </head>

    <body>
    	<?php
        	include("menu.php");
        	include("autenticado.php");
    	?>

    </body>

</html>
