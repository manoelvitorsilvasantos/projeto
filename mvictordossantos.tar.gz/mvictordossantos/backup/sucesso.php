
<!doctype>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="author" content="manoel vitor">
        <title> INFO CLIENTE</title>
        <link rel="stylesheet" type="text/css" href="estilo.css">
    </head>

    <body>
    	<?php
        	include("menu.php");
        	include("autenticado.php");
    	?>

        <div class="conteudo_center" align="center">
            </br>
            </br>
            </br>
            <h3> Registrado com sucesso...</h3>
            </br>
            </br>
            <a href="home.php">Voltar ao Menu!</a>
            </br>
            </br>
            </br>
        </div>

    </body>

</html>
