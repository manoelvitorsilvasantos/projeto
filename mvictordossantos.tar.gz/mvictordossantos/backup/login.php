
<!doctype>
<html lang="pt-br">
    <head>
        <?php
            include("cabeca.php");
			include("conexao.php");

            $conn = new Conexao();
        ?>
    </head>

    <body>
   		<?php
   			

   			$user = $_POST["email"];
   			$senha = $_POST["senha"];

   			$password = md5($senha);
   			
   			
   			session_start();
			

			$resultado = mysqli_query($conn->conectar(), "SELECT d.usuario, d.senha FROM usuarios AS d WHERE d.usuario = '$user' AND d.senha = '$password' ");
        
   			//$colunas = mysqli_num_rows($resultado);
			$colunas = mysqli_num_rows($resultado);
   			$linha = mysqli_fetch_assoc($resultado);
			echo $colunas;

   			if($colunas >= 1)
   			{
	
   				$_SESSION["email"] =  $linha["email"];
   				$_SESSION["senha"] = $linha["senha"];
   				session_cache_expire(5);
   				header('Location: home.php');
   			}
   			else{
				
   				unset($_SESSION["email"]);
   				unset($_SESSION["senha"]);
   				header('location: error.php');
   			}
   		?>
    </body>
</html>