<!doctype>
<html lang="pt-br">
    <head>
        <?php
            include("cabeca.php");
        ?>
        <script type="text/javascript">
            $(document).ready(function(){
                $("#cpf").mask("999.999.999-99");
            });
        </script>
    </head>

    <body>
        <?php
            include("menu.php");
            include("autenticado.php");
            
        ?>
        <div align="center" class="conteudo_center">
        </br>
        </br>        
            <form  name="form" action="registrar.php" method="POST" >
                </br>
                <h3 align="right"> Formulário de Cadastro</h3>
                </br>
                </br>
                <fieldset>
                    <legend>Dados Pessoais</legend>
                    <label>Nome: </label>
                    <input type="text" maxlength="60" placeholder="Seu nome completo" name="nome" pattern="[a-z\s]+$" title="Digite letra mínuscalas!"  required></br></br>

                    <label>CPF: </label>
                    <input type="text" name="cpf" onkeypress="MascaraCPF(form.cpf);" onblur="validaCPF(form.cpf);" maxlength="14" placeholder="Digite o número do CPF" required></br></br>

                    <label>RG: </label>
                    <input type="text" name="rg" onkeypress="MascaraRG(form.rg);"  maxlength="12" placeholder="Digite o número do RG" required></br></br>

                    <label>Data Nasc.: </label>
                    <input type="text" name="dn" onkeypress="MascaraData(form.dn);" onblur="validaData(form.dn);" placeholder="00/00/0000" maxlength="10" required></br></br>

                    <label>E-mail: </label>
                    <input type="email" maxlenght="50" placeholder="seuemail@dominio.com" name="email" placeholder="seuemail@dominio.com" autocomplete="on" required></br></br>

                    <label>Confirmar E-mail: </label>
                    <input type="email" placeholder="Repetir seuemail@dominio.com" name="email_confirma" required></br></br>

                    <label>Celular: </label>
                    <input type="text" name="cel" onkeypress="MascaraCelular(form.cel);" onblur="validaCelular(form.cel);" placeholder="(00) 00000-0000" maxlength="15" required></br></br>

                </fieldset></br></br>
                <fieldset>
                    <legend > Endereço</legend>
                    <label> Rua: </label> 
                    <input type="text" placeholder="Digite o seu endereco de rua" autocomplete="off" name="rua" required></br></br> 

                    <label> Bairro: </label> 
                    <input type="text" placeholder="Digite o nome do Bairro" autocomplete="on" name="bairro" required></br></br>
                    
                    <label> Cidade: </label> 
                    <input type="text" placeholder="Digite o nome da cidade" autocomplete="on" name="cidade" required></br></br>
                    
                    <label> Estado: </label> 
                    <select name="estado">
						<option value="Acre">Acre</option>
						<option value="Alagoas">Alagoas</option>
						<option value="Amap&aacute;">Amap&aacute;</option>
						<option value="Amazonas">Amazonas</option>
						<option value="Bahia">Bahia</option>
						<option value="Cear&aacute;">Cear&aacute;</option>
						<option value="Distrito Federal">Distrito Federal</option>
						
                    </select></br></br>


                    <label> CEP:</label>
                    <input type="text" autocomplete="on" name="cep" onkeypress="MascaraCep(form.cep);" onblur="validaCep(form.cep);" maxlength="10" placeholder="00.000-000" required> </br></br>

                    <label> Complemento: </label> 
                    <input type="text" autocomplete="on" name="complemento" required></br></br>

                    <label> Número: </label> 
                    <input type="number" placeholder="Digite o número" autocomplete="off" pattern="[0-9]+$" name="numero" required></br></br>
               

                </fieldset>
                </br>
                </br>
                <input type="submit" value="cadastrar">
                </br>
                </br>
                <input type="reset" value="Limpar">                
            </form>
        </div>
    </body>

</html>