<meta charset="UTF-8">
<meta name="author" content="manoel vitor">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title> INFO CLIENTE</title>
<link rel="stylesheet" type="text/css" href="estilo.css"/>
<script type="text/javascript" src="script.js"/></script>