<?php
	$res = md5("root");
	printf("%s", $res);
?>