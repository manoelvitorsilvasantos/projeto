
<!doctype>
<html lang="pt-br">
    <head>
        <?php
            include("cabeca.php");
        ?>
    </head>

    <body>
        <div class="conteudo_center">
            <form action="enviar_email" method="post">
            <br>
            <br>
            <label>Email to:</label><br>
            <input type="text" name="email">
            <br>
            <label>Título</label>
            <br>
            <input type="text" name="titulo">
            <br>
            <br>
            <textarea name="mensagem" cols="30" rows="10">
            </textarea>
            <br>
            <br>
            <input type="submit" value="Enviar">
            <br>
        </form>
        </div>
    </body>

</html>
