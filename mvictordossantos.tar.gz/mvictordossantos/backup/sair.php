
<!doctype>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="author" content="manoel vitor">
        <title> TELA DE LOGIN</title>
        <link rel="stylesheet" type="text/css" href="estilo.css">
    </head>

    <body>
        <?php
            session_start();
            session_destroy();
        ?>
        <div class="conteudo_center">
            <br>
            <br>
             <br>
             <h3> Deslogado do sistema!</h3>
             <br>
             <br>
             <br>
             <a href="index.php">Tela de Login</a>
            <br>
             <br>
            <br>
        </div>
    </body>

</html>
