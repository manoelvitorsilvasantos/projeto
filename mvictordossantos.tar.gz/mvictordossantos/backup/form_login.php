<?php
	echo " 
		<div class='conteudo_center'>
		<br>
		<form action='login.php' method='post' id='formulario-de-nota'>
		<fieldset align='center'>
		<legend> Tela de Login</legend>
		<label for='email'>Usuário</label>
		<input type='text' placeholder='Digite o seu usuário' name='email' required>
		<label for='senha'>Senha</label>
		<br>
		<input type='password' placeholder='Digite a sua senha' name='senha' required>
		</br>
		</br>
		</br>
		</br>
		<input type='submit' value='entrar'>
		</br>
		</br>
		<button type='button'> Esqueceu a senha</button>
		<br>
		</fieldset>
		</form>
		<div>
	";
?>