<?php
	/*
	session_start();

    $link = mysqli_connect("localhost:3306", "root", "root", "base_cliente");
    $resultado = mysqli_query($link, "SELECT *FROM usuarios");

    if(!$_SESSION["email"] ==  'root' && !$_SESSION["senha"] == 'root'){
        unset($_SESSION['email']);
        unset($_SESSION['senha']);
        header('Location: index.php');
   	}
	*/
?>