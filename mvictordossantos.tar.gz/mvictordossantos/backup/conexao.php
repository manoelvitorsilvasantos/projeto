<?php
	
	/**
	* Classe responsável por realizar a conexão com a base de dados.
	*/
	class Conexao{
		
		private $host = "localhost:3306";
		private $user = "root";
		private $pass = "root";
		private $database = "base_cliente";
		
		private $link;
		
		/**
		* Função responsável por realiar conexão com a base de dados propriamente.
		*/
		public function conectar()
		{
			$this->link = mysqli_connect($this->host, $this->user, $this->pass, $this->database);
			if(!$this->link)
			{
				echo "Erro ao realizar conexão com a base de dados!";
			}
			else
			{
				echo "Sucesso!";
			}
		}
		
	}

?>