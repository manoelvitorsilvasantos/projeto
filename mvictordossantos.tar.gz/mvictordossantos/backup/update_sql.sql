


	update ESTADO set name_estado = 'Amap&aacute;' where id = 3;
	update ESTADO set name_estado = 'Cear&aacute;' where id = 6;
	update ESTADO set name_estado = 'Esp&iacute;rito Santo;' where id = 8;
	update ESTADO set name_estado = 'Go&iacute;as;' where id = 9;
	update ESTADO set name_estado = 'Maranh&atilde;o' where id = 10;
	update ESTADO set name_estado = 'Par&aacute;' where id = 14;
	update ESTADO set name_estado = 'Para&iacute;ba' where id = 15;
	update ESTADO set name_estado = 'Paran&aacute;' where id = 16;
	update ESTADO set name_estado = 'Rond&ocirc;nia' where id = 22;
	update ESTADO set name_estado = 'S&atilde;o Paulo' where id = 25;

