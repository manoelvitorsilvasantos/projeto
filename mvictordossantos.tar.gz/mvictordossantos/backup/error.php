
<!doctype>
<html lang="pt-br">
    <head>
        <?php
            include("cabeca.php");
        ?>
    </head>

    <body>
    	<div class="conteudo_center">
            <br>
            <br>
             <br>
             <h3> Usuário ou Senha incorreto tente novamente!</h3>
             <br>
             <br>
             <br>
             <a href="index.php">Tela de Login</a>
            <br>
             <br>
            <br>
        </div>

    </body>

</html>