<?php
    
    include("autenticado.php");
    include("conexao.php");

    //variaveis capturados no formulário
    $nome = $_POST["nome"];
    $cpf = $_POST["cpf"]; 
    $rg = $_POST["rg"];
    $dn = $_POST["dn"];

    //variaveis de contatos
    $email = $_POST["email"];
    $email_confirma = $_POST["email_confirma"];
    $cel = $_POST["cel"];

    //variaveis
    $rua = $_POST["rua"];
    $bairro = $_POST["bairro"];
    $numero = $_POST["numero"];
    $cep = $_POST["cep"];
    $complemento = $_POST["complemento"];
    $estado = $_POST['estado'];
    $cidade = $_POST["cidade"];

    $conn = new Conexao();

    $tbl_cliente = mysqli_query($conn->conectar(), "INSERT INTO tbl_cliente(nome, cpf, rg, DN) values('{$nome}','{$cpf}','{$rg}','{$dn}')");

    $tbl_cliente_contato = mysqli_query($conn->conectar(), "INSERT INTO tbl_cliente_contato(cel, email, email_confirma) values('{$cel}', '{$email}', '{$email_confirma}')");

    $tbl_endereco = mysqli_query($conn->conectar(), "INSERT INTO tbl_endereco(rua, bairro, numero, cep, complemento, estado, cidade) VALUES('{$rua}', '{$bairro}', '{$numero}','{$cep}', '{$complemento}', '{$estado}', '{$cidade}')");

    $id = "(select LAST_INSERT_ID())";

    $tblUnidas = mysqli_query($conn->conectar(), "INSERT INTO tblUnidas(tbl_cliente, tbl_cliente_contato, tbl_endereco) values({$id}, {$id}, {$id})");
    


    if(!$tbl_cliente && !$tbl_cliente_contato && !$tbl_endereco && !$tblUnidas)
    {
    	echo "Erro, não foi possível registrar!";
    }
    else{
    	header('Location: sucesso.php');
    }


?>