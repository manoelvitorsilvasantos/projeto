
<!doctype>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="author" content="manoel vitor">
        <title> INFO CLIENTE</title>
        <link rel="stylesheet" type="text/css" href="estilo.css">
    </head>

    <body>
    	<?php
        	include("menu.php");
        	include("autenticado.php");
    	?>
    	<div class="lista" align="center">
    	</br>
    	<h2 align="left"> Lista de Clientes </h2>
    	
    		<?php
    			
    			include("conexao.php");
    			$conn = new Conexao();

    			$resultado = mysqli_query($conn->conectar(), "SELECT nome, cpf, rg, DN, cel, email, email_confirma, rua, bairro, cep, estado, numero, cidade, complemento FROM tblUnidas INNER JOIN tbl_cliente AS cl ON tblUnidas.tbl_cliente = cl.cod INNER JOIN tbl_cliente_contato AS co ON tblUnidas.tbl_cliente_contato = co.id INNER JOIN tbl_endereco AS en ON tblUnidas.tbl_endereco = en.id ORDER BY nome") or die(mysqli_error($conn->conectar()));

    			while($coluna = mysqli_fetch_assoc($resultado))
    			{
    				printf("<fieldset>");
    				printf("<legend> Dados Pessoais </legend>");
    				printf(" <p class='texto_lista'> Nome: %s </p>", $coluna['nome']);
    				printf(" <p class='texto_lista'> CPF:%s </p>", $coluna['cpf']);
    				printf(" <p class='texto_lista'> RG:%s </p>", $coluna['rg']);
    				printf(" <p class='texto_lista'> Email:%s </p>", $coluna['email']);
    				printf(" <p class='texto_lista'> Cel:%s </p>", $coluna['cel']);
    				printf("</fieldset>");
    				printf("</br></br>");

    				printf("<fieldset>");
    				printf("<legend> Dados Endere&ccedil;o </legend>");
    				printf(" <p class='texto_lista'> Rua:%s </p>", $coluna['rua']);
    				printf(" <p class='texto_lista'> Bairro:%s </p>", $coluna['bairro']);
    				printf(" <p class='texto_lista'> N&uacute;mero:%s </p>", $coluna['numero']);
    				printf(" <p class='texto_lista'> CEP:%s </p>", $coluna['cep']);
    				printf(" <p class='texto_lista'> Estado:%s </p>", $coluna['estado']);
    				printf(" <p class='texto_lista'> Cidade:%s </p>", $coluna['cidade']);
    				printf(" <p class='texto_lista'> Complemento.:%s </p>", $coluna['complemento']);
    				printf("</fieldset>");
    				printf("</br></br>");
	
    			}

    		?>
    	</div>
    </body>

</html>