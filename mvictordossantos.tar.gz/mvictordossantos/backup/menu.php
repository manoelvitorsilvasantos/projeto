<?php
 	echo "<div class='menu'>
        <a href='home.php'>Homepage </a>
        <a href='cadastrar.php'>Cadastrar</a>
        <a href='listar.php'>Listar</a>
        <a href='home.php'>Atualizar</a>
        <a href='home.php'>Remover</a>
        <a href='sair.php'>Sair</a>
    </div>"
?>